package mx.utng.s25.model.service;


public class UserServiceImpl implements IUserService {
   
    
}
