package mx.utng.s25.model.service;

public interface IUserService {
    
}
